from flask import Flask, render_template, request, jsonify, send_file
import requests
import pandas as pd
import math, csv, os, json
from io import BytesIO
from datetime import datetime

try:
    from gtts import gTTS
except ImportError:
    gTTS = None
import google.generativeai as genai  # 👈 Gemini integration

app = Flask(__name__)

# 🔑 Configure Gemini API
genai.configure(api_key="AIzaSyACgAlyAft0hXYXO0LfGD_RMU8j7zxnvOA")

# --- Load safety data ---
data = pd.read_csv("safety_data.csv")

# --- Load police station data ---
police_data = pd.read_csv("police_stations_with_coords.csv")

# --- File to store unsafe routes ---
UNSAFE_ROUTES_FILE = "unsafe_routes.json"
if not os.path.exists(UNSAFE_ROUTES_FILE):
    with open(UNSAFE_ROUTES_FILE, "w") as f:
        json.dump([], f)

# --- Multilingual dictionary ---
TRANSLATIONS = {
    "en": {
        "invalid_location": "Invalid location entered! Please try again.",
        "feedback_success": "✅ Feedback submitted successfully. Thank you for helping improve route safety!",
        "unsafe_chosen": "⚠️ This route was marked unsafe before. Selecting an alternate route."
    },
    "ta": {
        "invalid_location": "தவறான இடம் உள்ளிடப்பட்டுள்ளது! மீண்டும் முயற்சிக்கவும்.",
        "feedback_success": "✅ கருத்து வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது. வழித்தட பாதுகாப்பை மேம்படுத்தியதற்கு நன்றி!",
        "unsafe_chosen": "⚠️ இந்த வழி முன்பு பாதுகாப்பற்றதாகக் குறிக்கப்பட்டது. மாற்று வழியைத் தேர்ந்தெடுக்கப்படுகிறது."
    },
    "hi": {
        "invalid_location": "अमान्य स्थान दर्ज किया गया! कृपया पुनः प्रयास करें।",
        "feedback_success": "✅ प्रतिक्रिया सफलतापूर्वक सबमिट की गई। मार्ग सुरक्षा सुधारने में मदद के लिए धन्यवाद!",
        "unsafe_chosen": "⚠️ यह मार्ग पहले असुरक्षित के रूप में चिह्नित किया गया था। वैकल्पिक मार्ग चुना जा रहा है।"
    },
    "te": {
        "invalid_location": "చెల్లని స్థానం నమోదు చేయబడింది! దయచేసి మళ్లీ ప్రయత్నించండి.",
        "feedback_success": "✅ అభిప్రాయం విజయవంతంగా సమర్పించబడింది. రహదారి భద్రతను మెరుగుపరచడంలో సహాయం చేసినందుకు ధన్యవాదాలు!",
        "unsafe_chosen": "⚠️ ఈ మార్గం ఇంతకుముందు అసురక్షితంగా గుర్తించబడింది. ప్రత్యామ్నాయ మార్గాన్ని ఎంచుకుంటున్నాము."
    }
}

VOICE_LANG_MAP = {
    "en": "en",
    "ta": "ta",
    "hi": "hi"
}

def translate(lang, key):
    return TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, key)

# --- Haversine ---
def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

# --- Geocode ---
def get_coordinates(place_name):
    url = f"https://nominatim.openstreetmap.org/search?format=json&q={place_name}"
    try:
        response = requests.get(url, headers={'User-Agent': 'safe-route-app'}, timeout=8)
        data = response.json()
        if data:
            return float(data[0]['lat']), float(data[0]['lon'])
    except Exception as e:
        print("Geocoding error:", e)
    return None, None

# --- Nearby police ---
def get_nearby_police_stations(lat, lon, radius_km=3):
    nearby = []
    lat_col = "Latitude" if "Latitude" in police_data.columns else "latitude"
    lon_col = "Longitude" if "Longitude" in police_data.columns else "longitude"
    for _, row in police_data.iterrows():
        if not pd.isna(row[lat_col]) and not pd.isna(row[lon_col]):
            dist = haversine(lat, lon, row[lat_col], row[lon_col])
            if dist <= radius_km:
                nearby.append({
                    'name': row.get('Station Name', 'Unknown'),
                    'address': row.get('Type', 'N/A'),
                    'contact': row.get('Contact No.', 'N/A'),
                    'latitude': row[lat_col],
                    'longitude': row[lon_col],
                    'distance_km': round(dist, 2)
                })
    return nearby

# --- Unsafe route helpers ---
def get_unsafe_routes():
    with open(UNSAFE_ROUTES_FILE, "r") as f:
        return json.load(f)

def is_route_unsafe(start, end):
    unsafe_routes = get_unsafe_routes()
    for route in unsafe_routes:
        if route["start"].lower() == start.lower() and route["end"].lower() == end.lower():
            return True
    return False

# --- Gemini AI Safety Analysis ---
def analyze_safety_with_gemini(route_info):
    """
    Uses Gemini AI to analyze the given route context and safety metrics.
    """
    try:
        model_name = "gemini-2.0-flash"
        try:
            available = [
                model.name.rsplit("/", 1)[-1]
                for model in genai.list_models()
                if "generateContent" in getattr(model, "supported_generation_methods", [])
            ]
            for preferred in ("gemini-2.0-flash", "gemini-1.5-flash", "gemini-flash-latest"):
                if preferred in available:
                    model_name = preferred
                    break
            else:
                if available:
                    model_name = available[0]
        except Exception:
            pass

        model = genai.GenerativeModel(model_name)
        prompt = f"""
        Analyze the following route safety data and provide a concise risk level and reason:
        Data: {route_info}
        Return JSON with fields: risk_level (Low/Medium/High) and reason (short sentence).
        """
        response = model.generate_content(prompt)
        text = response.text.strip()
        json_start = text.find("{")
        json_end = text.rfind("}")
        if json_start != -1 and json_end != -1:
            structured = json.loads(text[json_start:json_end + 1])
        else:
            structured = {}
        risk_level = structured.get("risk_level") or "Medium"
        reason = structured.get("reason") or text
        return {"risk_level": risk_level, "reason": reason}
    except Exception as e:
        print("Gemini API error:", e)
        return {"risk_level": "Medium", "reason": "AI analysis unavailable"}


def load_feedback_entries(limit=None):
    entries = []
    if not os.path.exists("feedback.csv"):
        return entries
    with open("feedback.csv", "r", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row:
                continue
            timestamp = ""
            user = "Anonymous"
            start = ""
            end = ""
            rating = ""
            comment = ""
            if len(row) >= 6:
                timestamp, user, start, end, rating, comment = row[:6]
            elif len(row) == 5:
                user, start, end, rating, comment = row[:5]
            elif len(row) == 4:
                start, end, rating, comment = row[:4]
            elif len(row) >= 3:
                route, rating, comment = row[:3]
                parts = route.split(" to ")
                start = parts[0].strip() if parts else route
                end = parts[-1].strip() if len(parts) > 1 else ""
            else:
                continue
            entries.append(
                {
                    "timestamp": timestamp,
                    "user": user or "Anonymous",
                    "start": start,
                    "end": end,
                    "rating": rating,
                    "comment": comment,
                }
            )
    entries.sort(
        key=lambda x: x["timestamp"] or "",
        reverse=True,
    )
    if limit:
        return entries[:limit]
    return entries


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/get_safest_route', methods=['POST'])
def get_safest_route():
    data_req = request.json
    start_name = data_req['start']
    end_name = data_req['end']
    lang = data_req.get("lang", "en")

    # --- Geocode ---
    start_lat, start_lng = get_coordinates(start_name)
    end_lat, end_lng = get_coordinates(end_name)
    if not start_lat or not end_lat:
        return jsonify({'error': translate(lang, "invalid_location")})

    # --- Mock candidate routes ---
    routes = [
        {'name': 'Route A', 'path': [(start_lat, start_lng), (end_lat, end_lng)]},
        {'name': 'Route B', 'path': [(start_lat + 0.01, start_lng), (end_lat, end_lng + 0.01)]},
        {'name': 'Route C', 'path': [(start_lat, start_lng + 0.01), (end_lat + 0.01, end_lng)]}
    ]

    # --- Compute safety scores ---
    for route in routes:
        nearest = data.iloc[((data['latitude'] - route['path'][0][0])**2 +
                             (data['longitude'] - route['path'][0][1])**2).idxmin()]
        lighting = nearest['lighting']
        crowd = nearest['crowd']
        police = nearest['police_distance']
        crime = nearest['crime_rate']
        score = (0.4 * lighting) + (0.3 * crowd) + (0.2 * (1 - crime)) + (0.1 * (1 - police))
        route['safety_score'] = round(score, 2)
        # Use local fallback immediately; optional AI analysis must never block route generation.
        risk_level = "Low" if score >= 0.7 else "Medium" if score >= 0.45 else "High"
        route["ai_analysis"] = {
            "risk_level": risk_level,
            "reason": f"Safety score {route['safety_score']:.2f} based on lighting, crowd, police, and crime data"
        }

    # --- Sort routes ---
    sorted_routes = sorted(routes, key=lambda r: r['safety_score'], reverse=True)

    # --- If unsafe before ---
    unsafe_flag = is_route_unsafe(start_name, end_name)
    safest = sorted_routes[0]
    old_unsafe = None
    if unsafe_flag and len(sorted_routes) > 1:
        old_unsafe = sorted_routes[0]
        safest = sorted_routes[1]
        print(f"[⚠️] {translate(lang, 'unsafe_chosen')}")

    nearby_stations = get_nearby_police_stations(start_lat, start_lng)

    # --- Estimate travel time and route geometry ---
    duration_min = None
    distance_km = round(haversine(start_lat, start_lng, end_lat, end_lng), 2)
    route_geometry = [
        [start_lat, start_lng],
        [(start_lat + end_lat) / 2, (start_lng + end_lng) / 2],
        [end_lat, end_lng]
    ]
    route_steps = [
        {"instruction": "Start at " + start_name, "distance": 0, "duration": 0},
        {"instruction": "Continue toward " + end_name, "distance": distance_km * 1000, "duration": 0}
    ]

    try:
        osrm_url = (
            "https://router.project-osrm.org/route/v1/driving/"
            f"{start_lng},{start_lat};{end_lng},{end_lat}"
            "?overview=full&geometries=geojson&steps=true"
        )
        response = requests.get(osrm_url, timeout=8)
        route_data = response.json()
        if route_data.get("code") == "Ok" and route_data.get("routes"):
            route = route_data["routes"][0]
            route_geometry = [[coord[1], coord[0]] for coord in route["geometry"]["coordinates"]]
            distance_m = route["distance"]
            distance_km = round(distance_m / 1000, 2)
            duration_min = round(route["duration"] / 60, 1)
            route_steps = []
            for leg in route.get("legs", []):
                for step in leg.get("steps", []):
                    route_steps.append({
                        "instruction": step.get("name") or "Continue on the route",
                        "distance": step.get("distance", 0),
                        "duration": step.get("duration", 0)
                    })
    except Exception as e:
        print("Time fetch error:", e)
        duration_min = round(distance_km / 35 * 60, 1)

    if duration_min is None:
        duration_min = round(distance_km / 35 * 60, 1)

    nearest_station = None
    if nearby_stations:
        nearest_station = min(nearby_stations, key=lambda s: s['distance_km'])

    return jsonify({
        'safest_route': safest,
        'old_unsafe_route': old_unsafe,
        'nearby_police': nearby_stations,
        'estimated_time': duration_min,
        'distance_km': distance_km,
        'nearest_station': nearest_station,
        'orig_coord': [start_lat, start_lng],
        'dest_coord': [end_lat, end_lng],
        'route_geometry': route_geometry,
        'route_steps': route_steps
    })


@app.route("/tts", methods=["POST"])
def text_to_speech():
    if gTTS is None:
        return jsonify({"error": "Text-to-speech service is not configured on the server."}), 503

    payload = request.get_json(silent=True) or {}
    text = (payload.get("text") or "").strip()
    lang = payload.get("lang", "en")

    if not text:
        return jsonify({"error": "No text provided."}), 400

    lang_code = VOICE_LANG_MAP.get(lang, "en")

    try:
        tts = gTTS(text=text, lang=lang_code, slow=False)
        audio_buffer = BytesIO()
        tts.write_to_fp(audio_buffer)
        audio_buffer.seek(0)
        audio_buffer.name = "tts.mp3"
        response = send_file(audio_buffer, mimetype="audio/mpeg", as_attachment=False)
        response.headers["Cache-Control"] = "no-store"
        return response
    except Exception as e:
        print("TTS error:", e)
        return jsonify({"error": "Failed to generate speech."}), 500


@app.route("/submit_feedback", methods=["POST"])
def submit_feedback():
    data = request.get_json()
    rating = data.get("rating")
    comment = data.get("comment")
    route = data.get("route")
    start = data.get("start") or ""
    end = data.get("end") or ""
    user = data.get("user") or "Anonymous"
    lang = data.get("lang", "en")

    timestamp = datetime.utcnow().isoformat()

    os.makedirs(os.path.dirname("feedback.csv") or ".", exist_ok=True)
    with open("feedback.csv", "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([timestamp, user, start, end, rating, comment])

    if int(rating) <= 2 or "unsafe" in (comment or "").lower():
        start_name = start or route.split(" to ")[0].strip()
        end_name = end or route.split(" to ")[-1].strip()
        with open(UNSAFE_ROUTES_FILE, "r+") as f:
            unsafe_routes = json.load(f)
            if not any(r["start"].lower() == start_name.lower() and r["end"].lower() == end_name.lower() for r in unsafe_routes):
                unsafe_routes.append({"start": start_name, "end": end_name})
                f.seek(0)
                json.dump(unsafe_routes, f, indent=2)
                f.truncate()
                print(f"[🧩] Marked route {start_name} → {end_name} as unsafe.")
    entry = {
        "timestamp": timestamp,
        "user": user or "Anonymous",
        "start": start,
        "end": end,
        "rating": rating,
        "comment": comment,
    }
    return jsonify(
        {
            "message": translate(lang, "feedback_success"),
            "entry": entry,
        }
    )


@app.route("/feedbacks", methods=["GET"])
def get_feedbacks():
    limit = request.args.get("limit", type=int)
    entries = load_feedback_entries(limit=limit)
    return jsonify({"feedback": entries})


if __name__ == '__main__':
    app.run(debug=True)
