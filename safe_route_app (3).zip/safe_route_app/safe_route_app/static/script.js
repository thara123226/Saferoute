// ============================
// 🌐 Multilingual + Gemini Safe Route Script
// ============================

var map = L.map("map").setView([13.0827, 80.2707], 13);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);

let routeSteps = [];
let destination = "";
let navigationActive = false;
let navigationTimer = null;
let startTime = null;
let routeLayer = null;
let previousRouteLayer = null;
let startMarker = null;
let endMarker = null;
let currentLang = "en";
let currentAudio = null;
let currentAudioUrl = null;
let policeStations = [];
let policeMarkers = [];
let policeMarkerIndex = {};
let nearestStation = null;
let currentRouteSummary = {
  distanceKm: null,
  durationMin: null,
  safetyScore: null,
  aiAnalysis: null,
};
const aiReasonLocalized = {};
let latestAiReason = "";
let feedbackEntries = [];
const instructionTranslationCache = {};
const GEMINI_API_KEY = "AIzaSyACgAlyAft0hXYXO0LfGD_RMU8j7zxnvOA"; // ✅ Your key
const googleLangMap = {
  en: "en",
  ta: "ta",
  hi: "hi",
};

// 🌍 Translation dictionary (fallback if Gemini fails)
const translations = {
  en: {
    title: "AI-Based Safe Route Recommendation System for Women",
    startPlaceholder: "Enter start location (e.g., Chennai Central)",
    endPlaceholder: "Enter destination (e.g., Anna Nagar)",
    findRoute: "Find Safest Route",
    startNav: "🎤 Start Navigation",
    endJourney: "🏁 End Journey",
    languageLabel: "Language:",
    feedbackTitle: "💬 Route Feedback",
    feedbackPrompt: "Please rate the safety of this route:",
    submitFeedback: "Submit Feedback",
    nearbyTitle: "🚓 Nearby Police Stations",
    nearbySub: "Within 3 km radius from your start location",
    tableHead: ["Name", "Address", "Contact", "Distance (km)"],
    noStations: "No nearby police stations found within 3 km radius.",
    ai: "AI Risk Analysis",
    insightTitle: "AI Risk Insight",
    summaryTitle: "Route Summary",
    distanceLabel: "Distance",
    durationLabel: "Estimated Time",
    scoreLabel: "Safety Score",
    riskLabel: "AI Risk Level",
    nearestTitle: "Nearest Police Station",
    focusNearest: "Focus nearest",
    toggleUnsafe: "Show previous unsafe route",
    stepsTitle: "Turn-by-turn Steps",
    stepsPlaceholder: "No steps yet. Start navigation to view instructions.",
    aiInsightFallback: "AI analysis unavailable.",
    nearestBadge: "⭐ Nearest",
    noNearest: "None available",
    feedbackNamePlaceholder: "Your Name",
    feedbackDashboardTitle: "📊 Community Safety Feedback",
    feedbackEmpty: "No feedback yet. Complete a journey to share your experience.",
    feedbackRouteLabel: "Route",
    feedbackCommentLabel: "Feedback",
    feedbackNoComment: "No comment provided.",
    feedbackSharedBy: "Shared by",
    riskLevels: {
      Low: "Low",
      Medium: "Medium",
      High: "High",
    },
  },
  ta: {
    title: "பெண்களுக்கான செயற்கை நுண்ணறிவு அடிப்படையிலான பாதுகாப்பான பாதை பரிந்துரை அமைப்பு",
    startPlaceholder: "தொடக்க இடத்தை உள்ளிடவும் (உ.து: சென்னை சென்ட்ரல்)",
    endPlaceholder: "இலக்கு இடத்தை உள்ளிடவும் (உ.து: அண்ணா நகர்)",
    findRoute: "பாதுகாப்பான பாதையை கண்டறி",
    startNav: "🎤 வழிசெலுத்தல் தொடங்கு",
    endJourney: "🏁 பயணம் முடி",
    languageLabel: "மொழி:",
    feedbackTitle: "💬 பாதை கருத்து",
    feedbackPrompt: "இந்த பாதையின் பாதுகாப்பை மதிப்பிடவும்:",
    submitFeedback: "கருத்து சமர்ப்பி",
    nearbyTitle: "🚓 அருகிலுள்ள காவல் நிலையங்கள்",
    nearbySub: "உங்கள் தொடக்க இடத்திலிருந்து 3 கிமீ சுற்றளவில்",
    tableHead: ["பெயர்", "முகவரி", "தொடர்பு", "தூரம் (கி.மீ)"],
    noStations: "3 கி.மீ சுற்றளவில் அருகிலுள்ள காவல் நிலையங்கள் இல்லை.",
    ai: "AI அபாய பகுப்பாய்வு",
    insightTitle: "AI அபாய விளக்கம்",
    summaryTitle: "பாதை சுருக்கம்",
    distanceLabel: "தூரம்",
    durationLabel: "மதிப்பிடப்பட்ட நேரம்",
    scoreLabel: "பாதுகாப்பு மதிப்பெண்",
    riskLabel: "AI அபாய நிலை",
    nearestTitle: "அருகிலுள்ள காவல் நிலையம்",
    focusNearest: "அருகிலுள்ள நிலையம்",
    toggleUnsafe: "முன்னர் பாதுகாப்பற்ற பாதையை காட்டு",
    stepsTitle: "வழிச்செலுத்தல் படிகள்",
    stepsPlaceholder: "எந்த படிகளும் இல்லை. வழிசெலுத்தலைத் தொடங்கவும்.",
    aiInsightFallback: "AI பகுப்பாய்வு கிடைக்கவில்லை.",
    nearestBadge: "⭐ அருகில்",
    noNearest: "எதுவும் இல்லை",
    feedbackNamePlaceholder: "உங்கள் பெயர்",
    feedbackDashboardTitle: "📊 சமூக பாதுகாப்பு கருத்துக்கள்",
    feedbackEmpty: "கருத்துகள் இல்லை. பயணத்தை முடித்து உங்கள் அனுபவத்தை பகிரவும்.",
    feedbackRouteLabel: "பாதை",
    feedbackCommentLabel: "கருத்து",
    feedbackNoComment: "கருத்து வழங்கப்படவில்லை.",
    feedbackSharedBy: "பகிர்ந்தவர்",
    riskLevels: {
      Low: "குறைவு",
      Medium: "நடுத்தரம்",
      High: "அதிகம்",
    },
  },
  hi: {
    title: "महिलाओं के लिए एआई-आधारित सुरक्षित मार्ग अनुशंसा प्रणाली",
    startPlaceholder: "प्रारंभ स्थान दर्ज करें (जैसे, चेन्नई सेंट्रल)",
    endPlaceholder: "गंतव्य दर्ज करें (जैसे, अन्ना नगर)",
    findRoute: "सुरक्षित मार्ग खोजें",
    startNav: "🎤 नेविगेशन शुरू करें",
    endJourney: "🏁 यात्रा समाप्त करें",
    languageLabel: "भाषा:",
    feedbackTitle: "💬 मार्ग प्रतिक्रिया",
    feedbackPrompt: "कृपया इस मार्ग की सुरक्षा का मूल्यांकन करें:",
    submitFeedback: "प्रतिक्रिया भेजें",
    nearbyTitle: "🚓 निकटतम पुलिस स्टेशन",
    nearbySub: "आपके प्रारंभ स्थान से 3 किमी के दायरे में",
    tableHead: ["नाम", "पता", "संपर्क", "दूरी (किमी)"],
    noStations: "3 किमी के दायरे में कोई पुलिस स्टेशन नहीं मिला।",
    ai: "AI जोखिम विश्लेषण",
    insightTitle: "एआई जोखिम विश्लेषण",
    summaryTitle: "मार्ग सारांश",
    distanceLabel: "दूरी",
    durationLabel: "अनुमानित समय",
    scoreLabel: "सुरक्षा स्कोर",
    riskLabel: "एआई जोखिम स्तर",
    nearestTitle: "निकटतम पुलिस स्टेशन",
    focusNearest: "निकटतम स्टेशन देखें",
    toggleUnsafe: "पिछला असुरक्षित मार्ग दिखाएँ",
    stepsTitle: "टर्न-बाय-टर्न निर्देश",
    stepsPlaceholder: "अभी कोई निर्देश नहीं। नेविगेशन शुरू करें।",
    aiInsightFallback: "एआई विश्लेषण उपलब्ध नहीं है।",
    nearestBadge: "⭐ निकटतम",
    noNearest: "कोई उपलब्ध नहीं",
    feedbackNamePlaceholder: "आपका नाम",
    feedbackDashboardTitle: "📊 सामुदायिक सुरक्षा प्रतिक्रिया",
    feedbackEmpty: "अभी तक कोई प्रतिक्रिया नहीं। यात्रा पूरी करें और अपना अनुभव साझा करें।",
    feedbackRouteLabel: "मार्ग",
    feedbackCommentLabel: "प्रतिक्रिया",
    feedbackNoComment: "कोई टिप्पणी उपलब्ध नहीं है।",
    feedbackSharedBy: "साझा करने वाला",
    riskLevels: {
      Low: "कम",
      Medium: "मध्यम",
      High: "उच्च",
    },
  },
};

// 🧠 Translate text using Gemini API
async function geminiTranslate(text, targetLang) {
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `Translate this to ${targetLang}: ${text}` }] }],
        }),
      }
    );
    const data = await response.json();
    return (
      data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ||
      text
    );
  } catch (e) {
    console.error("Gemini translation failed:", e);
    return text;
  }
}

// 🔁 Change UI language
function changeLanguage(lang) {
  currentLang = lang;
  const t = translations[lang];

  document.querySelector("h2").innerText = t.title;
  document.getElementById("start").placeholder = t.startPlaceholder;
  document.getElementById("end").placeholder = t.endPlaceholder;
  document.getElementById("findRouteBtn").innerText = t.findRoute;
  document.getElementById("startNav").innerText = t.startNav;
  document.getElementById("endJourneyBtn").innerText = t.endJourney;
  document.querySelector("#feedbackSection h3").innerText = t.feedbackTitle;
  document.querySelector("#feedbackSection p").innerText = t.feedbackPrompt;
  document.querySelector("#feedbackSection button").innerText = t.submitFeedback;
  const languageLabel = document.getElementById("languageLabel");
  if (languageLabel) languageLabel.innerText = t.languageLabel;
  const summaryTitle = document.getElementById("summaryTitle");
  if (summaryTitle) summaryTitle.innerText = t.summaryTitle;
  const distanceLabel = document.getElementById("distanceLabel");
  if (distanceLabel) distanceLabel.innerText = t.distanceLabel;
  const durationLabel = document.getElementById("durationLabel");
  if (durationLabel) durationLabel.innerText = t.durationLabel;
  const scoreLabel = document.getElementById("scoreLabel");
  if (scoreLabel) scoreLabel.innerText = t.scoreLabel;
  const riskLabel = document.getElementById("riskLabel");
  if (riskLabel) riskLabel.innerText = t.riskLabel;
  const nearestTitle = document.getElementById("nearestTitle");
  if (nearestTitle) nearestTitle.innerText = t.nearestTitle;
  const focusNearestButton = document.getElementById("focusNearestButton");
  if (focusNearestButton)
    focusNearestButton.innerText = `📍 ${t.focusNearest}`;
  const toggleUnsafeText = document.getElementById("toggleUnsafeText");
  if (toggleUnsafeText) toggleUnsafeText.innerText = t.toggleUnsafe;
  const insightTitle = document.getElementById("insightTitle");
  if (insightTitle) insightTitle.innerText = t.insightTitle;
  const stepsTitle = document.getElementById("stepsTitle");
  if (stepsTitle) stepsTitle.innerText = t.stepsTitle;
  const userNameInput = document.getElementById("userName");
  if (userNameInput) userNameInput.placeholder = t.feedbackNamePlaceholder;
  const dashboardTitle = document.getElementById("feedbackDashboardTitle");
  if (dashboardTitle) dashboardTitle.innerText = t.feedbackDashboardTitle;
  const emptyState = document.getElementById("feedbackEmptyState");
  if (emptyState) emptyState.innerText = t.feedbackEmpty;

  renderStepList(routeSteps);
  updateRouteSummaryDisplay();
  updateAiInsightForLanguage(lang);
  renderFeedbackList();
}

function stopAudioPlayback() {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
  }
  if (currentAudioUrl) {
    URL.revokeObjectURL(currentAudioUrl);
  }
  currentAudio = null;
  currentAudioUrl = null;
  window.speechSynthesis.cancel();
}

function clearPoliceMarkers() {
  policeMarkers.forEach((marker) => {
    if (marker && map.hasLayer(marker)) {
      map.removeLayer(marker);
    }
  });
  policeMarkers = [];
  policeMarkerIndex = {};
}

function plotPoliceStationsOnMap(options = {}) {
  if (!policeStations.length) return;
  const { fitToBounds = true } = options;
  clearPoliceMarkers();
  const markers = [];
  policeStations.forEach((station, index) => {
    const lat = parseFloat(station.latitude);
    const lon = parseFloat(station.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
    const marker = L.marker([lat, lon], {
      title: station.name || "Police Station",
    }).addTo(map);
    const popupHtml = `
      <div style="font-weight:bold; margin-bottom:4px;">${
        station.name || "Police Station"
      }</div>
      <div>${station.address || ""}</div>
      <div>${station.contact ? `📞 ${station.contact}` : ""}</div>
      <div>${station.distance_km ? `📍 ${station.distance_km} km` : ""}</div>
    `;
    marker.bindPopup(popupHtml);
    markers.push(marker);
    const markerKey = station.markerKey || `${station.name || "Station"}_${index}`;
    policeMarkerIndex[markerKey] = marker;
    if (
      nearestStation?.markerKey &&
      markerKey === nearestStation.markerKey &&
      translations[currentLang]?.nearestBadge
    ) {
      marker.bindTooltip(translations[currentLang].nearestBadge, {
        direction: "top",
        offset: [0, -10],
        opacity: 0.85,
      });
    }
  });
  policeMarkers = markers;
  if (fitToBounds && policeMarkers.length) {
    const group = new L.featureGroup(policeMarkers);
    map.fitBounds(group.getBounds(), { padding: [40, 40] });
  }
}

function focusPoliceStationByKey(key) {
  if (!key) return;
  const marker = policeMarkerIndex[key];
  if (!marker) return;
  const latLng = marker.getLatLng();
  map.setView(latLng, Math.max(map.getZoom(), 15));
  marker.openPopup();
}

function onPoliceStationButtonClick(key) {
  focusPoliceStationByKey(key);
}

async function speakWithSynthesis(text) {
  return new Promise((resolve) => {
    const msg = new SpeechSynthesisUtterance(text);
    msg.lang =
      currentLang === "ta" ? "ta-IN" : currentLang === "hi" ? "hi-IN" : "en-IN";
    msg.rate = 1;
    msg.pitch = 1;
    msg.onend = resolve;
    msg.onerror = resolve;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(msg);
  });
}

function playAudioUrl(url) {
  return new Promise((resolve, reject) => {
    const audio = new Audio(url);
    currentAudio = audio;
    currentAudioUrl = url;

    const cleanup = () => {
      if (currentAudioUrl === url) {
        URL.revokeObjectURL(url);
        currentAudioUrl = null;
      }
      if (currentAudio === audio) {
        currentAudio = null;
      }
    };

    audio.addEventListener(
      "ended",
      () => {
        cleanup();
        resolve();
      },
      { once: true }
    );

    audio.addEventListener(
      "error",
      (event) => {
        cleanup();
        reject(event?.error || new Error("Audio playback error"));
      },
      { once: true }
    );

    const playPromise = audio.play();
    if (playPromise && typeof playPromise.then === "function") {
      playPromise.catch((err) => {
        cleanup();
        reject(err);
      });
    }
  });
}

// 🗣️ Voice output via hosted TTS with SpeechSynthesis fallback
async function speak(text) {
  const message = (text || "").toString().trim();
  if (!message) return;

  stopAudioPlayback();

  try {
    const response = await fetch("/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: message, lang: currentLang }),
    });

    if (!response.ok) {
      throw new Error(`TTS request failed with status ${response.status}`);
    }

    const audioBuffer = await response.arrayBuffer();
    if (!audioBuffer.byteLength) {
      throw new Error("Empty audio buffer received from TTS service");
    }

    const audioBlob = new Blob([audioBuffer], { type: "audio/mpeg" });
    const objectUrl = URL.createObjectURL(audioBlob);
    await playAudioUrl(objectUrl);
  } catch (error) {
    console.warn("Hosted TTS failed, falling back to SpeechSynthesis.", error);
    await speakWithSynthesis(message);
  }
}

async function getLocalizedSpeechText(text) {
  const trimmed = text.trim();
  if (!trimmed) return text;
  if (currentLang === "en") return trimmed;

  const cacheKey = `${currentLang}:${trimmed}`;
  if (instructionTranslationCache[cacheKey]) {
    return instructionTranslationCache[cacheKey];
  }

  const targetLangCode = googleLangMap[currentLang] || "en";
  if (targetLangCode !== "en") {
    const translated = await translateWithGoogle(trimmed, targetLangCode);
    if (translated && translated !== trimmed) {
      instructionTranslationCache[cacheKey] = translated;
      return translated;
    }
  }

  const targetLang =
    currentLang === "ta" ? "Tamil" : currentLang === "hi" ? "Hindi" : "English";
  const translated = await geminiTranslate(trimmed, targetLang);
  instructionTranslationCache[cacheKey] = translated;
  return translated;
}

async function translateWithGoogle(text, targetLangCode) {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLangCode}&dt=t&q=${encodeURIComponent(
      text
    )}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Google translate failed");
    const data = await res.json();
    if (Array.isArray(data) && Array.isArray(data[0])) {
      return data[0].map((part) => part[0]).join("").trim();
    }
  } catch (err) {
    console.warn("Google translation fallback failed:", err);
  }
  return text;
}

async function localizeDisplayText(text, lang = currentLang) {
  const trimmed = (text || "").toString().trim();
  if (!trimmed) return "";
  if (lang === "en") return trimmed;
  const code = googleLangMap[lang] || "en";
  const translated = await translateWithGoogle(trimmed, code);
  return translated || trimmed;
}

function getLocalizedRiskLabel(risk, lang = currentLang) {
  if (!risk) return "--";
  const normalized =
    risk.charAt(0).toUpperCase() + risk.slice(1).toLowerCase();
  const map = translations[lang]?.riskLevels || {};
  return map[normalized] || map[risk] || normalized;
}

function updateRouteSummaryDisplay() {
  const t = translations[currentLang];
  const distanceValue = document.getElementById("distanceValue");
  if (distanceValue) {
    distanceValue.innerText =
      typeof currentRouteSummary.distanceKm === "number"
        ? `${currentRouteSummary.distanceKm} km`
        : "--";
  }
  const durationValue = document.getElementById("durationValue");
  if (durationValue) {
    if (typeof currentRouteSummary.durationMin === "number") {
      const mins = Math.floor(currentRouteSummary.durationMin);
      const secs = Math.max(
        0,
        Math.round((currentRouteSummary.durationMin - mins) * 60)
      );
      durationValue.innerText =
        secs > 0 ? `${mins} min ${secs} sec` : `${mins} min`;
    } else {
      durationValue.innerText = "--";
    }
  }
  const scoreValue = document.getElementById("scoreValue");
  if (scoreValue) {
    scoreValue.innerText =
      typeof currentRouteSummary.safetyScore === "number"
        ? currentRouteSummary.safetyScore.toFixed(2)
        : "--";
  }
  const riskValue = document.getElementById("riskValue");
  if (riskValue) {
    const riskLevel = currentRouteSummary.aiAnalysis?.risk_level;
    riskValue.innerText = riskLevel
      ? getLocalizedRiskLabel(riskLevel)
      : "--";
  }
  const nearestValue = document.getElementById("nearestValue");
  if (nearestValue) {
    nearestValue.innerText = nearestStation?.name
      ? nearestStation.name
      : t.noNearest;
  }
  const focusButton = document.getElementById("focusNearestButton");
  if (focusButton) {
    focusButton.disabled = !nearestStation?.markerKey;
  }
}

async function updateAiInsightForLanguage(lang = currentLang) {
  const insightEl = document.getElementById("aiInsight");
  if (!insightEl) return;
  const t = translations[lang];
  if (!latestAiReason) {
    insightEl.innerText = t.aiInsightFallback;
    return;
  }
  if (!aiReasonLocalized[lang]) {
    aiReasonLocalized[lang] =
      lang === "en"
        ? latestAiReason
        : await localizeDisplayText(latestAiReason, lang);
  }
  insightEl.innerText =
    aiReasonLocalized[lang] && aiReasonLocalized[lang].trim().length > 0
      ? aiReasonLocalized[lang]
      : t.aiInsightFallback;
}

function enrichStations(stations = []) {
  return stations.map((station, index) => {
    const key = `${station.name || "Station"}_${station.latitude || ""}_${
      station.longitude || ""
    }_${index}`;
    return { ...station, markerKey: key };
  });
}

function renderStepList(steps) {
  const list = document.getElementById("stepsList");
  if (!list) return;
  list.innerHTML = "";
  if (!steps || !steps.length) {
    list.innerHTML = `<li class="placeholder" id="stepsPlaceholder">${translations[currentLang].stepsPlaceholder}</li>`;
    return;
  }
  steps.forEach((step, index) => {
    const text = step.instruction.replace(/<[^>]*>/g, "");
    const item = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = text;
    const button = document.createElement("button");
    button.className = "step-audio";
    button.dataset.index = index;
    button.textContent = "🔊";
    button.addEventListener("click", async (evt) => {
      evt.preventDefault();
      await speakStepByIndex(Number(evt.currentTarget.dataset.index));
    });
    item.appendChild(span);
    item.appendChild(button);
    list.appendChild(item);
  });
}

async function speakStepByIndex(index) {
  if (
    typeof index !== "number" ||
    index < 0 ||
    index >= routeSteps.length
  )
    return;
  const text = routeSteps[index].instruction.replace(/<[^>]*>/g, "");
  const localized = await getLocalizedSpeechText(text);
  await speak(localized);
}

function formatRatingStars(rating) {
  const value = Math.round(Number(rating) || 0);
  const clamped = Math.max(0, Math.min(5, value));
  const filled = "⭐".repeat(clamped);
  const empty = "☆".repeat(5 - clamped);
  return filled + empty;
}

function renderFeedbackList(entriesParam = feedbackEntries) {
  const listEl = document.getElementById("feedbackList");
  if (!listEl) return;
  listEl.innerHTML = "";
  const t = translations[currentLang];
  if (!entriesParam || !entriesParam.length) {
    const empty = document.createElement("p");
    empty.className = "placeholder";
    empty.id = "feedbackEmptyState";
    empty.innerText = t.feedbackEmpty;
    listEl.appendChild(empty);
    return;
  }
  entriesParam.forEach((entry) => {
    const card = document.createElement("div");
    card.className = "feedback-card";

    const header = document.createElement("div");
    header.className = "header";
    const userName = entry.user || "Anonymous";
    header.innerHTML = `<span>${t.feedbackSharedBy} ${userName}</span><span>${formatRatingStars(entry.rating)}</span>`;

    const routeLine = document.createElement("div");
    routeLine.className = "route";
    const startName = entry.start || (entry.route ? entry.route.split(" to ")[0] : "") || "Unknown";
    const endName =
      entry.end ||
      (entry.route && entry.route.split(" to ").slice(-1)[0]) ||
      "Unknown";
    routeLine.innerHTML = `<strong>${t.feedbackRouteLabel}:</strong> ${startName} → ${endName}`;

    const comment = document.createElement("p");
    comment.className = "comment";
    comment.innerText =
      entry.comment && entry.comment.trim()
        ? entry.comment.trim()
        : t.feedbackNoComment;

    card.appendChild(header);
    card.appendChild(routeLine);
    card.appendChild(comment);
    listEl.appendChild(card);
  });
}

async function loadFeedbackEntries() {
  try {
    const res = await fetch("/feedbacks");
    if (!res.ok) throw new Error(`Failed to load feedback (${res.status})`);
    const data = await res.json();
    const fetched = Array.isArray(data.feedback) ? data.feedback : [];
    feedbackEntries = fetched.map((entry) => ({
      ...entry,
      user: entry.user || "Anonymous",
      start: entry.start || "",
      end: entry.end || "",
      rating: entry.rating || "",
      comment: entry.comment || "",
    }));
    renderFeedbackList();
  } catch (err) {
    console.error("Unable to load feedback entries:", err);
  }
}

// 🚀 Find safest route
async function findSafeRoute() {
  const start = document.getElementById("start").value.trim();
  const end = document.getElementById("end").value.trim();
  const navButton = document.getElementById("startNav");
  const endButton = document.getElementById("endJourneyBtn");
  const stationSection = document.getElementById("policeInfo");
  const feedbackSection = document.getElementById("feedbackSection");

  feedbackSection.style.display = "none";
  endButton.style.display = "none";
  clearPoliceMarkers();
  policeStations = [];

  if (!start || !end) {
    alert("⚠️ Please enter both locations!");
    return;
  }

  await speak(
    currentLang === "ta"
      ? `${start} இலிருந்து ${end} வரை பாதுகாப்பான பாதையை கண்டறிகிறேன்`
      : currentLang === "hi"
      ? `${start} से ${end} तक सुरक्षित मार्ग खोज रहा हूँ`
      : `Finding safest route from ${start} to ${end}`
  );

  const res = await fetch("/get_safest_route", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ start, end, lang: currentLang }),
  });
  const data = await res.json();

  if (data.error) {
    alert(data.error);
    return;
  }

  const startCoord = Array.isArray(data.orig_coord)
    ? data.orig_coord
    : null;
  const endCoord = Array.isArray(data.dest_coord)
    ? data.dest_coord
    : null;
  if (!startCoord || !endCoord) {
    alert("❌ Could not determine the route coordinates.");
    return;
  }

  const rawStations = Array.isArray(data.nearby_police)
    ? data.nearby_police
    : [];
  policeStations = enrichStations(rawStations);
  const nearbyStations = policeStations;
  const safest = data.safest_route;
  const oldUnsafe = data.old_unsafe_route;
  const toggleWrapper = document.getElementById("toggleUnsafeWrapper");
  const toggleCheckbox = document.getElementById("toggleUnsafeRoute");

  if (toggleWrapper) {
    toggleWrapper.style.display =
      oldUnsafe && oldUnsafe.path ? "flex" : "none";
  }
  if (toggleCheckbox) {
    toggleCheckbox.checked = false;
  }

  nearestStation = null;
  if (data.nearest_station) {
    nearestStation =
      policeStations.find(
        (station) =>
          station.name === data.nearest_station.name &&
          station.distance_km === data.nearest_station.distance_km
      ) || null;
  }
  if (!nearestStation && policeStations.length) {
    nearestStation = policeStations[0];
  }

  // 🧹 Clear old layers
  if (previousRouteLayer && map.hasLayer(previousRouteLayer)) {
    map.removeLayer(previousRouteLayer);
  }
  previousRouteLayer = null;
  map.eachLayer((layer) => {
    if (layer instanceof L.Polyline || layer instanceof L.Marker)
      map.removeLayer(layer);
  });

  // 🔴 Unsafe route
  if (oldUnsafe && oldUnsafe.path) {
    const redCoords = oldUnsafe.path.map((c) => [c[0], c[1]]);
    previousRouteLayer = L.polyline(redCoords, {
      color: "red",
      weight: 4,
      dashArray: "6,6",
      opacity: 0.6,
    });
    if (toggleCheckbox && toggleCheckbox.checked) {
      previousRouteLayer.addTo(map);
    }
  }

  // 🟢 Safe route
  const coords = Array.isArray(data.route_geometry) && data.route_geometry.length
    ? data.route_geometry
    : [startCoord, endCoord];

  routeSteps = Array.isArray(data.route_steps) && data.route_steps.length
    ? data.route_steps
    : [{ instruction: `Continue to ${end}`, distance: 0, duration: 0 }];
  destination = end;

  routeLayer = L.polyline(coords, {
    color: "limegreen",
    weight: 6,
    opacity: 0.9,
  }).addTo(map);

  startMarker = L.marker(startCoord).addTo(map).bindPopup(`<b>${start}</b>`);
  endMarker = L.marker(endCoord).addTo(map).bindPopup(`<b>${end}</b>`);

  // 🚓 Police Stations
  if (nearbyStations.length > 0) {
    let html = `
      <div class="police-header">
        <h3>${translations[currentLang].nearbyTitle}</h3>
        <p>${translations[currentLang].nearbySub}</p>
      </div>
      <table class="police-table">
        <thead><tr>
          <th>${translations[currentLang].tableHead[0]}</th>
          <th>${translations[currentLang].tableHead[1]}</th>
          <th>${translations[currentLang].tableHead[2]}</th>
          <th>${translations[currentLang].tableHead[3]}</th>
        </tr></thead>
        <tbody>`;
    nearbyStations.forEach((st) => {
      const stationName = st.name || "Police Station";
      html += `<tr>
        <td>
          <button class="station-link" data-station="${st.markerKey}">
            ${stationName}
          </button>
        </td>
        <td>${st.address || ""}</td>
        <td>${st.contact || ""}</td>
        <td>${st.distance_km || ""}</td>
      </tr>`;
    });
    html += `</tbody></table>`;
    stationSection.innerHTML = html;
    stationSection.style.display = "block";
    document.querySelectorAll(".station-link").forEach((button) => {
      button.addEventListener("click", (evt) => {
        const targetKey = evt.currentTarget.getAttribute("data-station");
        onPoliceStationButtonClick(targetKey);
      });
    });
  } else {
    stationSection.innerHTML = `<p>${translations[currentLang].noStations}</p>`;
    stationSection.style.display = "block";
  }

  plotPoliceStationsOnMap({ fitToBounds: false });

  const backendDistance =
    typeof data.distance_km === "number"
      ? data.distance_km
      : Number.isFinite(parseFloat(data.distance_km))
      ? parseFloat(data.distance_km)
      : null;
  const backendDuration =
    typeof data.estimated_time === "number"
      ? data.estimated_time
      : Number.isFinite(parseFloat(data.estimated_time))
      ? parseFloat(data.estimated_time)
      : null;
  const distanceNumeric = Number.isFinite(backendDistance)
    ? backendDistance
    : null;
  const durationNumeric = Number.isFinite(backendDuration)
    ? backendDuration
    : null;
  currentRouteSummary = {
    distanceKm: Number.isFinite(distanceNumeric) ? Number(distanceNumeric.toFixed(2)) : null,
    durationMin: Number.isFinite(durationNumeric) ? durationNumeric : null,
    safetyScore:
      typeof safest?.safety_score === "number" ? safest.safety_score : null,
    aiAnalysis: safest?.ai_analysis || null,
  };
  for (const key in aiReasonLocalized) {
    if (Object.prototype.hasOwnProperty.call(aiReasonLocalized, key)) {
      delete aiReasonLocalized[key];
    }
  }
  latestAiReason = currentRouteSummary.aiAnalysis?.reason || "";
  if (latestAiReason && /ai analysis unavailable/i.test(latestAiReason)) {
    latestAiReason = "";
  }
  if (latestAiReason) {
    aiReasonLocalized.en = latestAiReason;
  }

  updateRouteSummaryDisplay();
  renderStepList(routeSteps);
  await updateAiInsightForLanguage(currentLang);
  map.fitBounds(routeLayer.getBounds());
  navButton.disabled = false;
  navButton.style.backgroundColor = "#007bff";
  const speechInsight =
    aiReasonLocalized[currentLang] || latestAiReason;
  if (speechInsight) {
    await speak(speechInsight);
  }
}

// 🎤 Navigation (same as before)
async function startVoiceNavigation() {
  if (!routeSteps.length) {
    alert("No route loaded yet!");
    return;
  }
  stopAudioPlayback();
  navigationActive = true;
  startTime = new Date();
  await speak(
    currentLang === "ta"
      ? "வழிசெலுத்தல் தொடங்குகிறது"
      : currentLang === "hi"
      ? "नेविगेशन शुरू हो रहा है"
      : "Starting navigation."
  );
  const btn = document.getElementById("startNav");
  const endButton = document.getElementById("endJourneyBtn");
  btn.disabled = true;
  btn.style.backgroundColor = "gray";
  endButton.style.display = "inline-block";

  let i = 0;
  const delay = 7000;
  const speakNext = async () => {
    if (!navigationActive) return;
    if (i < routeSteps.length) {
      const text = routeSteps[i].instruction.replace(/<[^>]*>/g, "");
      const localizedText = await getLocalizedSpeechText(text);
      await speak(localizedText);
      if (!navigationActive) return;
      i++;
      navigationTimer = setTimeout(speakNext, delay);
    } else {
      endJourney(true);
    }
  };
  speakNext();
}

async function endJourney(auto = false) {
  if (!navigationActive && !auto) return;
  navigationActive = false;
  clearTimeout(navigationTimer);
  navigationTimer = null;
  stopAudioPlayback();
  plotPoliceStationsOnMap();

  const endTime = new Date();
  const totalSeconds = Math.floor((endTime - startTime) / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const timeTaken = `${minutes} min ${seconds} sec`;

  await speak(
    currentLang === "ta"
      ? `பயணம் முடிந்தது. மொத்த நேரம் ${timeTaken}.`
      : currentLang === "hi"
      ? `यात्रा समाप्त हुई। कुल समय ${timeTaken}।`
      : `Journey ended. Total time ${timeTaken}.`
  );

  showFeedbackForm();
}

function showFeedbackForm() {
  const feedbackSection = document.getElementById("feedbackSection");
  feedbackSection.style.display = "block";
  document.getElementById("endJourneyBtn").style.display = "none";
  window.scrollTo(0, document.body.scrollHeight);
}

async function submitFeedback() {
  const rating = document.querySelector('input[name="rating"]:checked');
  const comment = document.getElementById("comment").value.trim();
  const start = document.getElementById("start").value.trim();
  const end = document.getElementById("end").value.trim();
  const userName = document.getElementById("userName").value.trim();

  if (!rating) {
    alert("Please give a rating!");
    return;
  }

  const res = await fetch("/submit_feedback", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      rating: rating.value,
      comment: comment,
      route: `${start} to ${end}`,
      start,
      end,
      user: userName,
      lang: currentLang,
    }),
  });

  const data = await res.json();
  alert(data.message);
  document.getElementById("feedbackSection").style.display = "none";
  document.getElementById("comment").value = "";
  document.getElementById("userName").value = "";
  document
    .querySelectorAll('input[name="rating"]')
    .forEach((input) => (input.checked = false));
  await loadFeedbackEntries();
}

document.addEventListener("DOMContentLoaded", () => {
  renderFeedbackList();
  loadFeedbackEntries();
  const userNameInputInit = document.getElementById("userName");
  if (userNameInputInit) {
    userNameInputInit.placeholder =
      translations[currentLang].feedbackNamePlaceholder;
  }
  const focusButton = document.getElementById("focusNearestButton");
  if (focusButton) {
    focusButton.addEventListener("click", () => {
      if (nearestStation?.markerKey) {
        focusPoliceStationByKey(nearestStation.markerKey);
      }
    });
  }

  const toggleCheckbox = document.getElementById("toggleUnsafeRoute");
  if (toggleCheckbox) {
    toggleCheckbox.addEventListener("change", (evt) => {
      if (!previousRouteLayer) return;
      if (evt.target.checked) {
        previousRouteLayer.addTo(map);
      } else if (map.hasLayer(previousRouteLayer)) {
        map.removeLayer(previousRouteLayer);
      }
    });
  }
});
